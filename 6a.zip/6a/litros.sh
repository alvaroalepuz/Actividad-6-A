numero=0
gastos=0
while [[ $num -le 0 ]]; do
	read-p "Litros de agua consumidos:"numero
	if [ $numero -le 0 ]; then
		echo "El numero debe ser mayor que 0"
	fi
done

if [[ $numero -gt 200 ]]; then
	numero=$((num-200))
	gastos=$((2000+20*150+10*numero))
elif [[ $numero -gt 50 ]]; then
	num=$((num-50))
	gastos=$((2000+20*numero))
else
	gastos=2000
fi
gastos=echo "scale=2; $gastos/100" | bc
echo "El gasto total es de $gastos"