numero=$1
acumulador=0
media=0
until [[ $numero == 0 ]]; do

	((acumulador+=numero))
done

((media=acumulador/numero))
echo "LA suma total es $acumulador"
echo "la media es $media"