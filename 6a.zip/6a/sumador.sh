numero=$1
contador=0

until [[ $contador -eq $numero ]]; do

	echo $contador

	((contador++))
done