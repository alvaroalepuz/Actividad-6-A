numero=$1


if [[ $numero -lt 5 ]]; then
	echo "suspendido con un $numero"
fi
if [[ $numero -gt 4 && $numero -lt 7 ]]; then
	echo "aprobado con un $numero"
fi
if [[ $numero -lt 9 && $numero -gt 7 ]]; then
	echo "notable con un $numero"
fi
if [[ $numero -lt 11 && $numero -gt 8 ]]; then
	echo "sobresaliente con un $numero"
fi
