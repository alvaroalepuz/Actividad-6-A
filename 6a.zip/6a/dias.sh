dia=$1

case $dia in
		1 | 8 | 15 | 22 | 29 )
		echo "El dia $dia es Lunes" 
		;;
		2 |9 | 16 | 23 | 30 )
		echo "El dia $dia es Martes" 
		;;
		3 | 10 | 17 | 24 )
		echo "El dia $dia es Miercoles" 
		;;
		4 | 11 | 18 | 25 )
		echo "El dia $dia es Jueves" 
		;;
		5 | 12 | 19 | 26 )
		echo "El dia $dia es Viernes" 
		;;
		6 | 13 | 20 | 27 )
		echo "El dia $dia es Sabado" 
		;;
		7 | 14 | 21 | 28 )
		echo "El dia $dia es Domingo" 
		;;

esac