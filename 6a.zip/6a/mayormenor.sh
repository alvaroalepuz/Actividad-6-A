a=$1
b=$2

if [[ "$a" -eq "$b" ]]; then
	echo "$a es igual que $b"
fi

if [[ "$a" -gt "$b"  ]]; then
	echo "$a es mayor que $b"
fi

if [[ "$a" -lt "$b"  ]]; then
	echo "$a es menor que $b"
fi