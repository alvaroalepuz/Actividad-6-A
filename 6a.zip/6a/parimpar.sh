numero=$1


if [[ $numero%2 -eq 0 ]]; then
	echo "El numero $numero es par"
else
	echo "El numero $numero es impar"
fi